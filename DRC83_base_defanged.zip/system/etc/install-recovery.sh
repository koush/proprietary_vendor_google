#!/system/bin/sh
log -t recovery "Not installing recovery image"
