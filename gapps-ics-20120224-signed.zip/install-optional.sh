#!/sbin/sh

if [ -e /system/etc/permissions/android.hardware.camera.front.xml ]; then
        echo "Installing face detection support"
        cp -a /tmp/face/* /system/
fi
rm -rf /tmp/face

if ( ! grep -q "neon" /proc/cpuinfo ); then
        echo "Installing support for non-NEON target"
        cp -a /tmp/noneon/* /system/
fi
rm -rf /tmp/noneon

